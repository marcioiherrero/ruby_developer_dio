class ArticlesController < ApplicationController
  def index
  end
end
